function otvoriNovi(){
    var noviProzor = window.open("prijava2.html","newWindow", "width =700,height = 700,top=200,left=200")
}
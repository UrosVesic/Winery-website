function otvoriNovi(){
    if(daLiJeUBuducnosti()){
        var noviProzor = window.open("prijava2.html","newWindow", "width =700,height = 700,top=200,left=200");
        console.log("buducnost");
    }
    else{
        console.log("proslost");
    }
}
function daLiJeUBuducnosti(){
    var datum = document.getElementById('datepicker').datepicker('getDate');
    var sada = new Date();
    sada.setHours(0,0,0,0);
    if(datum>now){
        return false
    }
    else{
        return true;
    }
}
$( function() {
    $( "#datepicker" ).datepicker();
  } );